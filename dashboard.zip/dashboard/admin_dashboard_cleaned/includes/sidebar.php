<div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
        <div class="d-flex align-items-center justify-content-center border-bottom py-3 mb-3">
            <a href="/admin-dashboard" class="text-decoration-none">
                <i class="bi bi-box me-2"></i>
                <span class="fs-5 fw-semibold">Admin Dashboard</span>
            </a>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php' && dirname($_SERVER['PHP_SELF']) == '/admin-dashboard') ? 'active' : ''; ?>" href="../admin_dashboard_cleaned/index.php">
                    <i class="bi bi-speedometer2 me-2"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], '/users/') !== false) ? 'active' : ''; ?>" href="../admin_dashboard_cleaned/users/index.php">
                    <i class="bi bi-people me-2"></i>
                    Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], '/products/') !== false) ? 'active' : ''; ?>" href="../admin_dashboard_cleaned/products/index.php">
                    <i class="bi bi-box-seam me-2"></i>
                    Products
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], '/cart/') !== false) ? 'active' : ''; ?>" href="../admin_dashboard_cleaned/orders/index.php">
                    <i class="bi bi-cart me-2"></i>
                    Orders
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="bi bi-gear me-2"></i>
                    Settings
                </a>
            </li>
        </ul>
        <div class="border-top my-3"></div>
        <div class="px-3">
            <a href="../../../greenguru/Login page/login.html">
            <button class="btn btn-outline-secondary w-100 d-flex align-items-center" >
                <i class="bi bi-box-arrow-right me-2"></i>
                Logout
            </button>
            </a>
        </div>
    </div>
</div>

